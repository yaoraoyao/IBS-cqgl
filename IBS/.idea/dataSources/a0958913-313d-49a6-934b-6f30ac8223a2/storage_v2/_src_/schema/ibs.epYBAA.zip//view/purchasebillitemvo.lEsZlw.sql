CREATE VIEW purchasebillitemvo AS
  SELECT
    `item`.`id`     AS `id`,
    `item`.`price`  AS `price`,
    `item`.`num`    AS `num`,
    `item`.`amount` AS `amount`,
    `item`.`descs`  AS `descs`,
    `pt`.`name`     AS `productTypeName`,
    `p`.`name`      AS `productName`,
    `bill`.`id`     AS `billId`,
    `bill`.`vdate`  AS `vdate`,
    `bill`.`status` AS `status`,
    `e`.`username`  AS `buyerName`,
    `s`.`name`      AS `supplierName`
  FROM `ibs`.`purchasebillitem` `item`
    JOIN `ibs`.`purchasebill` `bill`
    JOIN `ibs`.`product` `p`
    JOIN `ibs`.`producttype` `pt`
    JOIN `ibs`.`employee` `e`
    JOIN `ibs`.`supplier` `s`
  WHERE ((`item`.`bill_id` = `bill`.`id`) AND (`bill`.`buyer_id` = `e`.`id`) AND (`bill`.`supplier_id` = `s`.`id`) AND
         (`item`.`product_id` = `p`.`id`) AND (`p`.`types_id` = `pt`.`id`));

