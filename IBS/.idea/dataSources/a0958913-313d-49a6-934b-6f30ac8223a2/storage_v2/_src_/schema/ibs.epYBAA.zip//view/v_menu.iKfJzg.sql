CREATE VIEW v_menu AS
  SELECT
    `m1`.`id`                              AS `id`,
    `m1`.`name`                            AS `name`,
    `m1`.`url`                             AS `url`,
    `m1`.`icon`                            AS `icon`,
    `m1`.`parent_id`                       AS `parent_id`,
    (SELECT `m2`.`name`
     FROM `ibs`.`menu` `m2`
     WHERE (`m2`.`id` = `m1`.`parent_id`)) AS `parentName`
  FROM `ibs`.`menu` `m1`;

